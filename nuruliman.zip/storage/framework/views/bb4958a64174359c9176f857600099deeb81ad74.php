<?php $__env->startSection('content'); ?>
    <section id="header-ekskul">
        <div class="title">
            <h1>Exskul</h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nuruliman\resources\views/frontend/ekskul.blade.php ENDPATH**/ ?>