<?php
    $uri = Request::segment(1);
?>

<!-- ======= Header ======= -->
<header id="header">
<div class="container d-flex">

    <div class="logo mr-auto">
        <h1 class="text-light">
            <a href="<?php echo e(route('home.index')); ?>">
                <img src="<?php echo e(url('frontend/assets/img/logo.png')); ?>" id="logo-bang" alt="Logo Nurul Iman">
            </a>
        </h1>
    </div>

    <nav class="nav-menu d-none d-lg-block">
    <ul>
        <li <?php if($uri == null): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('home.index')); ?>">Beranda</a></li>
        <li <?php if($uri == "profile"): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('profile.index')); ?>">Profile</a></li>
        <li <?php if($uri == "program"): ?> class="active drop-down" <?php endif; ?> class="drop-down"><a href="">Program</a>
            <ul>
                <?php $__currentLoopData = \App\Program::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('program.index',\Str::lower($program->name))); ?>"><?php echo e($program->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li <?php if($uri == "ekskul"): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('ekskul.index')); ?>">Extra Kulikuler</a></li>
        <li <?php if($uri == "pendaftaran"): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('pendaftaran.index')); ?>">Pendaftaran</a></li>

    </ul>
    </nav><!-- .nav-menu -->

</div>
</header><!-- End Header -->
<?php /**PATH C:\xampp\htdocs\nuruliman\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>