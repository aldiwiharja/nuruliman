@extends('frontend.layouts.app')

@section('content')
    <section id="header-ekskul">
        <div class="title">
            <h1>Exskul</h1>
        </div>
    </section>
@endsection