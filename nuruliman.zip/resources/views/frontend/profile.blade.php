@extends('frontend.layouts.app')

@section('content')
    <section id="header-profile">
        <div class="title">
            <h1>Profile</h1>
        </div>
    </section>
@endsection